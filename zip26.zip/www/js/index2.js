
function toggle1()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("quizpopup1");
    popup.classList.toggle("active");
} 

function toggle2()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("quizpopup2");
    popup.classList.toggle("active");
} 
function toggle3()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("quizpopup3");
    popup.classList.toggle("active");
} 

function toggle4()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mockpopup1");
    popup.classList.toggle("active");
}   
function toggle5()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mockpopup2");
    popup.classList.toggle("active");
}   
function toggle6()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mockpopup3");
    popup.classList.toggle("active");
}   
function toggle7()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("roadpopup1");
    popup.classList.toggle("active");
}   
function toggle8()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("roadpopup2");
    popup.classList.toggle("active");
}   
function toggle9()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("roadpopup3");
    popup.classList.toggle("active");
}   
function toggle10()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("robopopup1");
    popup.classList.toggle("active");
}   
function toggle11()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("robopopup2");
    popup.classList.toggle("active");
}   
function toggle12()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("riffpopup");
    popup.classList.toggle("active");
}  
function toggle13()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("monpopup1");
    popup.classList.toggle("active");
}   
function toggle14()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("monpopup2");
    popup.classList.toggle("active");
}   
function toggle15()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("monpopup3");
    popup.classList.toggle("active");
} 
function toggle16()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("bripopup1");
    popup.classList.toggle("active");
}   
function toggle17()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("bripopup2");
    popup.classList.toggle("active");
}   
function toggle18()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("bripopup3");
    popup.classList.toggle("active");
} 
function toggle19()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("kalpopup1");
    popup.classList.toggle("active");
}   
function toggle20()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("kalpopup2");
    popup.classList.toggle("active");
}   
function toggle21()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("kalpopup3");
    popup.classList.toggle("active");
} 
function toggle22()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("techpopup1");
    popup.classList.toggle("active");
}   
function toggle23()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("techpopup2");
    popup.classList.toggle("active");
}   
function toggle24()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("techpopup3");
    popup.classList.toggle("active");
} 
function toggle25()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("burnpopup1");
    popup.classList.toggle("active");
}   
function toggle26()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("burnpopup2");
    popup.classList.toggle("active");
}   
function toggle27()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("burnpopup3");
    popup.classList.toggle("active");
} 
function toggle28()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("bhapopup");
    popup.classList.toggle("active");
} 
function toggle29()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("elecpopup1");
    popup.classList.toggle("active");
}   
function toggle30()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("elecpopup2");
    popup.classList.toggle("active");
}   
function toggle31()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("elecpopup3");
    popup.classList.toggle("active");
} 
function toggle32()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("hogpopup1");
    popup.classList.toggle("active");
}   
function toggle33()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("hogpopup2");
    popup.classList.toggle("active");
}
function toggle34()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("shutpopup1");
    popup.classList.toggle("active");
}   
function toggle35()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("shutpopup2");
    popup.classList.toggle("active");
}   
function toggle36()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("shutpopup3");
    popup.classList.toggle("active");
} 
function toggle37()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("provepopup1");
    popup.classList.toggle("active");
}   
function toggle38()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("provepopup2");
    popup.classList.toggle("active");
}   
function toggle39()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("provepopup3");
    popup.classList.toggle("active");
}
function toggle40()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("duetpopup");
    popup.classList.toggle("active");
}   
function toggle41()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("battlepopup");
    popup.classList.toggle("active");
}
function toggle42()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("vibepopup");
    popup.classList.toggle("active");
}
function toggle43()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("talentpopup1");
    popup.classList.toggle("active");
}
function toggle44()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("talentpopup2");
    popup.classList.toggle("active");
}

function toggle45()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("codepopup1");
    popup.classList.toggle("active");
}
function toggle46()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("codepopup2");
    popup.classList.toggle("active");
}
function toggle47()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("masterpopup1");
    popup.classList.toggle("active");
}
function toggle48()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("masterpopup2");
    popup.classList.toggle("active");
}
function toggle49()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("khampopup1");
    popup.classList.toggle("active");
}
function toggle50()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("khampopup2");
    popup.classList.toggle("active");
}
function toggle51()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("davincipopup");
    popup.classList.toggle("active");
}
function toggle52()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("ampopup");
    popup.classList.toggle("active");
}
function toggle53()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("vocalpopup");
    popup.classList.toggle("active");
}
function toggle54()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("intelpopup");
    popup.classList.toggle("active");
}
function toggle55()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("slowpopup");
    popup.classList.toggle("active");
}
function toggle56()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("stomppopup");
    popup.classList.toggle("active");
}
function toggle57()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mascarapopup");
    popup.classList.toggle("active");
}
function toggle58()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("couturepopup");
    popup.classList.toggle("active");
}
