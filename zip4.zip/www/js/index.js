setTimeout(changepages,3000)
function changepages()
{
    document.getElementById("firstpage").style.display="none";
    document.getElementById("secondpage").style.display="";
}

document.getElementById("b1").addEventListener("click",fun1);
function fun1()
{

}