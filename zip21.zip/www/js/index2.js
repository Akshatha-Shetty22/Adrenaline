
function toggle1()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("quizpopup1");
    popup.classList.toggle("active");
} 

function toggle2()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("quizpopup2");
    popup.classList.toggle("active");
} 
function toggle3()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("quizpopup3");
    popup.classList.toggle("active");
} 

function toggle4()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mockpopup1");
    popup.classList.toggle("active");
}   
function toggle5()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mockpopup2");
    popup.classList.toggle("active");
}   
function toggle6()
{
    var blur=document.getElementById("fourthpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("mockpopup3");
    popup.classList.toggle("active");
}   
function toggle7()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("roadpopup1");
    popup.classList.toggle("active");
}   
function toggle8()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("roadpopup2");
    popup.classList.toggle("active");
}   
function toggle9()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("roadpopup3");
    popup.classList.toggle("active");
}   
function toggle10()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("robopopup1");
    popup.classList.toggle("active");
}   
function toggle11()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("robopopup2");
    popup.classList.toggle("active");
}   
function toggle12()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("riffpopup");
    popup.classList.toggle("active");
}  
function toggle13()
{
    var blur=document.getElementById("firstpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("monpopup1");
    popup.classList.toggle("active");
}   
function toggle14()
{
    var blur=document.getElementById("secondpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("monpopup2");
    popup.classList.toggle("active");
}   
function toggle15()
{
    var blur=document.getElementById("thirdpage1");
    blur.classList.toggle("active");
    var popup=document.getElementById("monpopup3");
    popup.classList.toggle("active");
} 