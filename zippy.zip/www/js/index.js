setTimeout(changepages,2000);
function changepages()
{
    document.getElementById("firstpage").style.display="none";
    document.getElementById("secondpage").style.display="";
}