document.getElementById("d1").addEventListener("click",fun1);
document.getElementById("d2").addEventListener("click",fun2);
function fun1()
{
    
    document.getElementById("secondpage1").style.display="none";
    document.getElementById("firstpage1").style.display="";
}

function fun2()
{
    document.getElementById("firstpage1").style.display="none";
    document.getElementById("secondpage1").style.display="";
}
              
