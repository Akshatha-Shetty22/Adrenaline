

document.getElementById("b1").addEventListener("click",fun1);
function fun1()
{

}